// tools/go/mk_hint.go
// Small tool to generate a textual hint based on seed; demonstrates Go usage in the repo.
//
// Usage: go run mk_hint.go -seed=20251201-abc123
package main

import (
	"flag"
	"fmt"
	"hash/fnv"
	"strings"
)

func hintFromSeed(seed string) string {
	h := fnv.New32a()
	h.Write([]byte(seed))
	v := h.Sum32()
	colors := []string{"violet", "cyan", "magenta", "indigo", "silver"}
	verbs := []string{"observe", "suivre", "cliquer", "décrypter", "aligner"}
	idx := int(v%uint32(len(colors)))
	return fmt.Sprintf("Indice : %s les étoiles de couleur %s.", verbs[v%uint32(uint32(len(verbs)))], colors[idx])
}

func main() {
	seed := flag.String("seed", "default", "seed pour générer l'indice")
	flag.Parse()
	fmt.Println(strings.ToUpper("=== HINT GENERATOR ==="))
	fmt.Println(hintFromSeed(*seed))
}
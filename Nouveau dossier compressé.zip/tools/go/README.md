# Outils Go
Ce dossier contient de petits utilitaires en Go pour générer des seeds ou indices.
Exemples:
  go run gen_seed.go -n 3
  go run mk_hint.go -seed=20251201-xxxxx
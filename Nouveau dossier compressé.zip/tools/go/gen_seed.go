package main

import (
	"crypto/rand"
	"encoding/hex"
	"flag"
	"fmt"
	"os"
	"time"
)

// Petit utilitaire Go pour générer une seed pour les énigmes/stars
func main() {
	n := flag.Int("n", 1, "nombre de seeds à générer")
	flag.Parse()
	for i := 0; i < *n; i++ {
		b := make([]byte, 16)
		_, err := rand.Read(b)
		if err != nil {
			fmt.Fprintln(os.Stderr, "erreur:", err)
			return
		}
		fmt.Printf("%s-%s\n", time.Now().Format("20060102"), hex.EncodeToString(b))
	}
}
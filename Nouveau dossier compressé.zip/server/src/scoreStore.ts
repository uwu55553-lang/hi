// server/src/scoreStore.ts
// Simple in-memory score store with optional persistence to disk (JSON).
import fs from 'fs';
import path from 'path';

const DB_FILE = path.join(__dirname, '../../data/scores.json');

type Score = { name: string; score: number; time: number };

class ScoreStore {
  private scores: Score[] = [];

  constructor() {
    this.load();
  }

  private load() {
    try {
      if (fs.existsSync(DB_FILE)) {
        const text = fs.readFileSync(DB_FILE, 'utf-8');
        this.scores = JSON.parse(text);
      } else {
        this.scores = [];
      }
    } catch (e) {
      console.error('Failed loading scores:', e);
      this.scores = [];
    }
  }

  private save() {
    try {
      fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
      fs.writeFileSync(DB_FILE, JSON.stringify(this.scores.slice(0, 200), null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed saving scores', e);
    }
  }

  add(name: string, score: number) {
    if (!name) name = 'anon';
    this.scores.push({ name, score, time: Date.now() });
    this.scores.sort((a, b) => b.score - a.score || a.time - b.time);
    if (this.scores.length > 200) this.scores = this.scores.slice(0, 200);
    this.save();
  }

  top(n = 20) {
    return this.scores.slice(0, n);
  }
}

export const scoreStore = new ScoreStore();
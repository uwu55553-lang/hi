// server/src/index.ts
import express from 'express';
import cors from 'cors';
import path from 'path';
import { WebSocketServer } from 'ws';
import { scoreStore } from './scoreStore';

const app = express();
app.use(cors());
app.use(express.json());
const PORT = Number(process.env.PORT || 3000);

app.get('/api/health', (req, res) => res.send({ ok: true, time: Date.now() }));

app.post('/api/score', (req, res) => {
  const { name, score } = req.body;
  if (typeof score !== 'number') return res.status(400).send({ error: 'invalid score' });
  scoreStore.add(String(name || 'anon'), score);
  res.send({ ok: true });
});

app.get('/api/scores', (req, res) => {
  res.send(scoreStore.top(20));
});

app.use('/', express.static(path.join(__dirname, '../../dist')));

const server = app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});

const wss = new WebSocketServer({ server });
wss.on('connection', (ws) => {
  console.log('WS connected');
  ws.on('message', (msg) => {
    // broadcast to all other clients
    wss.clients.forEach((c) => {
      if (c !== ws && c.readyState === 1) {
        c.send(msg.toString());
      }
    });
  });
});
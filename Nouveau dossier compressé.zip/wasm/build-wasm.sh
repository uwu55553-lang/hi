#!/bin/sh
# Simple helper script to build the wasm package with wasm-pack (assumes wasm-pack installed)
set -e
cd "$(dirname "$0")"
echo "Building wasm..."
wasm-pack build --target web --release
echo "WASM build completed. The pkg/ folder now contains wasm_sim.js and wasm_sim_bg.wasm"
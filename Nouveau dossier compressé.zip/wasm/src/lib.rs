// wasm/src/lib.rs
// Rust simulation for particles compiled to WASM with wasm-bindgen.
// This implementation keeps a simple pool of particles and exposes functions:
// - run_init(width, height, max_particles)
// - set_pointer(x, y)
// - burst(x, y, count, hue)
// - step_frame() -> Vec<f32> (flat float array: x,y,s,h,a ...)
// - particle_count() -> u32
//
// The implementation aims to be efficient: uses Vec, reuses particles, avoids allocations
// on each frame except when returning the Vec<f32> which wasm-bindgen will translate to JS TypedArray.

use wasm_bindgen::prelude::*;
use std::f32::consts::PI;
use rand::{rngs::SmallRng, Rng, SeedableRng};
use std::cell::RefCell;

#[wasm_bindgen]
extern {
    // optional console.log
    #[wasm_bindgen(js_namespace = console)]
    fn log(s: &str);
}

#[derive(Clone)]
struct Particle {
    x: f32,
    y: f32,
    vx: f32,
    vy: f32,
    s: f32,
    h: f32,
    a: f32,
    life: f32,
}

impl Particle {
    fn new(x: f32, y: f32, s: f32, h: f32) -> Self {
        let mut rng = SmallRng::from_entropy();
        Particle {
            x,
            y,
            vx: (rng.gen::<f32>() - 0.5) * 6.0,
            vy: (rng.gen::<f32>() - 0.5) * 6.0,
            s,
            h,
            a: 1.0,
            life: 1.0,
        }
    }
}

thread_local! {
    static STATE: RefCell<SimState> = RefCell::new(SimState::new());
}

struct SimState {
    width: f32,
    height: f32,
    max_particles: usize,
    particles: Vec<Particle>,
    pointer_x: f32,
    pointer_y: f32,
    pointer_enabled: bool,
    rng: SmallRng,
    frame_tmp: Vec<f32>, // temporary buffer returned to JS
}

impl SimState {
    fn new() -> Self {
        SimState {
            width: 800.0,
            height: 600.0,
            max_particles: 1200,
            particles: Vec::with_capacity(1024),
            pointer_x: 0.0,
            pointer_y: 0.0,
            pointer_enabled: false,
            rng: SmallRng::from_entropy(),
            frame_tmp: Vec::new(),
        }
    }

    fn spawn(&mut self, x: f32, y: f32, count: usize, hue: f32) {
        for _ in 0..count {
            if self.particles.len() >= self.max_particles { break; }
            let s = 1.0 + self.rng.gen::<f32>() * 3.2;
            let h = hue + (self.rng.gen::<f32>() - 0.5) * 40.0;
            let p = Particle::new(x + (self.rng.gen::<f32>()-0.5)*20.0, y + (self.rng.gen::<f32>()-0.5)*20.0, s, h);
            self.particles.push(p);
        }
    }

    fn step(&mut self, dt: f32) {
        // update particles
        let mut i = 0usize;
        while i < self.particles.len() {
            {
                let p = &mut self.particles[i];
                if self.pointer_enabled {
                    let dx = self.pointer_x - p.x;
                    let dy = self.pointer_y - p.y;
                    let d2 = dx*dx + dy*dy + 0.001;
                    let d = d2.sqrt();
                    let f = (600.0 / d).min(12.0) * 0.06;
                    p.vx += (dx / d) * f;
                    p.vy += (dy / d) * f;
                    // swirl
                    p.vx += (d.sin()) * 0.02;
                    p.vy -= (d.cos()) * 0.02;
                }
                p.x += p.vx * dt;
                p.y += p.vy * dt;
                p.vx *= 0.96;
                p.vy *= 0.96;
                p.s *= 0.998;
                p.life -= 0.003 * dt;
                p.a = p.life.max(0.0);
            }
            // removal conditions
            if self.particles[i].life <= 0.0 || self.particles[i].s < 0.2 || self.particles[i].x.is_nan() || self.particles[i].y.is_nan() {
                // swap remove
                self.particles.swap_remove(i);
            } else {
                i += 1;
            }
        }
    }

    fn to_f32_buffer(&mut self) -> Vec<f32> {
        // Pack into x,y,s,h,a
        self.frame_tmp.clear();
        self.frame_tmp.reserve(self.particles.len() * 5);
        for p in &self.particles {
            self.frame_tmp.push(p.x);
            self.frame_tmp.push(p.y);
            self.frame_tmp.push(p.s);
            self.frame_tmp.push(p.h);
            self.frame_tmp.push(p.a);
        }
        self.frame_tmp.clone()
    }
}

#[wasm_bindgen]
pub fn run_init(w: u32, h: u32, max_particles: u32) {
    console_error_panic_hook::set_once();
    STATE.with(|s| {
        let mut st = s.borrow_mut();
        st.width = w as f32;
        st.height = h as f32;
        st.max_particles = max_particles as usize;
        st.particles.clear();
        // spawn gentle ambient particles
        for _ in 0..(max_particles.min(200) as usize) {
            let x = st.rng.gen::<f32>() * st.width;
            let y = st.rng.gen::<f32>() * st.height;
            st.spawn(x, y, 1, 220.0 + st.rng.gen::<f32>() * 40.0);
        }
    });
}

#[wasm_bindgen]
pub fn set_pointer(x: f32, y: f32) {
    STATE.with(|s| {
        let mut st = s.borrow_mut();
        st.pointer_x = x;
        st.pointer_y = y;
        st.pointer_enabled = true;
    });
}

#[wasm_bindgen]
pub fn burst(x: f32, y: f32, count: u32, hue: f32) {
    STATE.with(|s| {
        let mut st = s.borrow_mut();
        st.spawn(x, y, count as usize, hue);
    });
}

#[wasm_bindgen]
pub fn particle_count() -> u32 {
    STATE.with(|s| {
        let st = s.borrow();
        st.particles.len() as u32
    })
}

#[wasm_bindgen]
pub fn step_frame() -> Vec<f32> {
    // execute one step (dt approximated as 1 for simplicity; main loop in worker uses a dt scale)
    STATE.with(|s| {
        let mut st = s.borrow_mut();
        st.step(1.0);
        st.to_f32_buffer()
    })
}
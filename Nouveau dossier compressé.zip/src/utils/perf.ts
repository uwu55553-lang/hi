// src/utils/perf.ts
// Simple FPS & frame budget monitor
export class PerfMonitor {
  private last = performance.now();
  private frames = 0;
  private fps = 60;
  private cb?: (fps:number)=>void;
  constructor(cb?: (fps:number)=>void) { this.cb = cb; setInterval(()=>this.tick(),1000); }
  frame() { this.frames++; }
  private tick() {
    const now = performance.now();
    const f = this.frames;
    this.fps = Math.round((f*1000)/(now - this.last));
    this.frames = 0;
    this.last = now;
    if (this.cb) this.cb(this.fps);
  }
  getFps() { return this.fps; }
}
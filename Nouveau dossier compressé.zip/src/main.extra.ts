// Hook extra modules into the main app (this file should be imported by src/main.ts when present).
import { installKonami } from './ui/konami';
import { createLeaderboardPanel } from './ui/leaderboard';
import { createPuzzleOverlay } from './ui/puzzle-overlay';

export function wireExtras(portal: any) {
  // konami opens portal immediate spectacular
  installKonami(() => {
    // little pulse + open
    portal.requestOpen();
    alert('Konami activated — portal unlocked');
  });

  // attach leaderboard
  const lb = createLeaderboardPanel(document.getElementById('ui-root')!, '/api');

  // puzzle overlay manage events
  const overlay = createPuzzleOverlay(document.body, () => {
    // hint requested -> forward to portal
    portal.openPuzzle(); // show puzzle details; worker will send hint if available
    setTimeout(()=> alert('Indice: observe les scintillements plus lents.'), 200);
  }, () => {
    // cancel
    const panel = document.querySelector('.panel');
    if (panel) panel.classList.add('hidden');
  });

  // update overlay progress from portal events if portal exposes events
  if (portal && portal.on) {
    portal.on('puzzle-progress', (pct:number) => {
      overlay.setProgress(pct);
    });
  }
}
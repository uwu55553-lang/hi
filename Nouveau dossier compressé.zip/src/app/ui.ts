import mitt from 'mitt';
import { Portal } from './Portal';

const emitter = mitt();

export function createPortalUI(root: HTMLElement, portal: Portal) {
  const container = document.createElement('div');
  container.className = 'portal-panel';
  container.innerHTML = `
    <div class="h1">✨ PORTAIL COSMIQUE ULTIME ✨</div>
    <div style="display:flex;gap:12px;justify-content:center;align-items:center;flex-wrap:wrap">
      <button id="enterBtn" class="primary-btn">🌌 ENTRER DANS LE PORTAIL 🌌</button>
      <button id="solveBtn" style="background:transparent;border:1px solid rgba(255,255,255,0.06);padding:10px;border-radius:8px;color:#fff;cursor:pointer">Énigme</button>
    </div>
    <div class="small-muted">Indices et pièges discrets intégrés. CPU-friendly (WASM + WebWorker).</div>
  `;
  root.appendChild(container);

  const enterBtn = container.querySelector('#enterBtn') as HTMLButtonElement;
  const solveBtn = container.querySelector('#solveBtn') as HTMLButtonElement;

  enterBtn.addEventListener('click', () => {
    portal.requestOpen();
  });
  solveBtn.addEventListener('click', () => {
    portal.openPuzzle();
  });

  // particle count display
  const count = document.createElement('div');
  count.className = 'particle-count';
  count.textContent = '✨ Particules: 0';
  document.body.appendChild(count);

  portal.on('particles', (n: number) => {
    count.textContent = `✨ Particules: ${n}`;
  });
}
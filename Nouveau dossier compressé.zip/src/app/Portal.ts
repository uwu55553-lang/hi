// Portal: orchestre rendu canvas, worker wasm, énigmes, interactions
import mitt from 'mitt';

// types
type Events = {
  particles: number;
  solved: null;
};

export class Portal {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private worker?: Worker;
  private running = false;
  private particlesCount = 0;
  private emitter = mitt<Events>();
  private mouse = { x: 0, y: 0 };
  private deviceMemory = (navigator as any).deviceMemory || 4;
  private maxParticles = Math.max(300, Math.min(2000, Math.floor(this.deviceMemory * 300)));

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) throw new Error('Canvas context not supported');
    this.ctx = ctx;
    this.resize();
    this.installListeners();
  }

  on<E extends keyof Events>(ev: E, cb: (payload: Events[E]) => void) {
    this.emitter.on(ev as string, cb as any);
  }

  resize() {
    this.canvas.width = innerWidth;
    this.canvas.height = innerHeight;
  }

  installListeners() {
    addEventListener('mousemove', (e) => {
      this.mouse.x = e.clientX;
      this.mouse.y = e.clientY;
      // small local feedback
      if (this.running) this.sendCommand({ type: 'pointer', x: this.mouse.x, y: this.mouse.y });
    });
    addEventListener('click', (e) => {
      this.sendCommand({ type: 'burst', x: e.clientX, y: e.clientY });
    });
  }

  start() {
    // try to start a worker that uses WASM simulation
    if (typeof Worker !== 'undefined') {
      this.worker = new Worker(new URL('../workers/wasmWorker.ts', import.meta.url), { type: 'module' });
      this.worker.onmessage = (ev) => {
        const msg = ev.data;
        if (msg.type === 'render') {
          this.renderFromBuffer(msg.buffer, msg.meta);
        } else if (msg.type === 'stats') {
          this.particlesCount = msg.particles;
          this.emitter.emit('particles', msg.particles);
        } else if (msg.type === 'solved') {
          this.emitter.emit('solved', null);
          this.playOpenSequence();
        }
      };
      // initialize worker with config safe-limits based on device
      this.worker.postMessage({
        type: 'init',
        width: this.canvas.width,
        height: this.canvas.height,
        maxParticles: this.maxParticles
      });
      this.running = true;
    } else {
      // fallback: local JS simulation (lighter)
      console.warn('Worker not available, using fallback simulation (lighter).');
      this.running = true;
    }
    requestAnimationFrame(() => this.loop());
  }

  sendCommand(cmd: any) {
    if (this.worker) this.worker.postMessage(cmd);
  }

  loop() {
    if (!this.running) return;
    // main loop does not draw particles directly; worker sends frames via transferable buffers
    requestAnimationFrame(() => this.loop());
  }

  renderFromBuffer(buffer: ArrayBuffer, meta: any) {
    // buffer contains Float32Array sequence [x,y,size,hue,alpha,...]
    const f32 = new Float32Array(buffer);
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    // subtle background fade
    this.ctx.fillStyle = 'rgba(0,0,0,0.08)';
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    for (let i = 0; i < f32.length; i += 5) {
      const x = f32[i], y = f32[i + 1], s = f32[i + 2], h = f32[i + 3], a = f32[i + 4];
      this.ctx.save();
      this.ctx.beginPath();
      this.ctx.fillStyle = `hsla(${Math.floor(h)},85%,60%,${a})`;
      this.ctx.shadowBlur = Math.min(40, s * 8);
      this.ctx.shadowColor = `hsl(${Math.floor(h)},85%,60%)`;
      this.ctx.globalAlpha = a;
      this.ctx.arc(x, y, Math.max(0.3, s), 0, Math.PI * 2);
      this.ctx.fill();
      this.ctx.restore();
    }
  }

  requestOpen() {
    // direct open - pulses then tells worker to open
    this.sendCommand({ type: 'pulse', x: this.canvas.width / 2, y: this.canvas.height / 2 });
  }

  openPuzzle() {
    // ask worker to spawn an interactive puzzle (constellation)
    this.sendCommand({ type: 'puzzle' });
  }

  playOpenSequence() {
    // small local visual feedback when puzzle solved
    for (let i = 0; i < 6; i++) {
      setTimeout(() => {
        this.sendCommand({ type: 'burst', x: this.canvas.width / 2 + (Math.random() - 0.5) * 300, y: this.canvas.height / 2 + (Math.random() - 0.5) * 200, count: 80 });
      }, i * 120);
    }
    // optionally trigger fullscreen video or further actions by emitting event
  }
}
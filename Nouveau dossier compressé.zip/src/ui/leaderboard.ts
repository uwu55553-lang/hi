// src/ui/leaderboard.ts
// Simple leaderboard UI that fetches scores from server and renders a panel.
// Uses minimal DOM APIs to avoid large frameworks.
type Score = { name: string; score: number; time: number };

export function createLeaderboardPanel(container: HTMLElement, apiBase = '/api') {
  const panel = document.createElement('div');
  panel.className = 'panel';
  panel.style.position = 'absolute';
  panel.style.bottom = '18px';
  panel.style.left = '18px';
  panel.style.maxWidth = '320px';
  panel.style.zIndex = '60';
  panel.innerHTML = `<h3>Classement</h3><div id="lb-list" style="max-height:240px; overflow:auto;"></div><div style="display:flex;gap:8px;margin-top:8px"><input id="lb-name" placeholder="Nom" style="flex:1;padding:8px;border-radius:6px;border:1px solid rgba(255,255,255,0.06)"><button id="lb-submit" class="btn">Envoyer</button></div>`;
  container.appendChild(panel);

  const list = panel.querySelector('#lb-list') as HTMLElement;
  const nameInput = panel.querySelector('#lb-name') as HTMLInputElement;
  const submit = panel.querySelector('#lb-submit') as HTMLButtonElement;

  async function refresh() {
    try {
      const res = await fetch(apiBase + '/scores');
      if (!res.ok) throw new Error('fetch failed');
      const data: Score[] = await res.json();
      list.innerHTML = data.map((s, idx) => `<div style="padding:6px;border-bottom:1px dashed rgba(255,255,255,0.03)"><strong>#${idx+1} ${escapeHtml(s.name)}</strong> — ${s.score}</div>`).join('');
    } catch (e) {
      list.textContent = 'Impossible de récupérer le classement';
      console.error(e);
    }
  }
  submit.addEventListener('click', async () => {
    const name = nameInput.value.trim() || 'anon';
    // For the demo, send a random score
    const score = Math.floor(Math.random() * 5000);
    try {
      await fetch(apiBase + '/score', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, score })
      });
      nameInput.value = '';
      await refresh();
      alert('Score envoyé 🎉 (c\'était un score aléatoire pour la demo)');
    } catch (e) {
      alert('Échec envoi score');
    }
  });

  refresh();
  return { refresh, panel };
}

function escapeHtml(s: string) {
  return s.replace(/[&<>"']/g, (m) => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":"&#39;" }[m]!));
}
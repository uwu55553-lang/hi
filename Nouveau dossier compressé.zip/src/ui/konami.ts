// src/ui/konami.ts
// Konami easter egg handler (exported)
export function installKonami(fn: () => void) {
  const seq = ['ArrowUp','ArrowUp','ArrowDown','ArrowDown','ArrowLeft','ArrowRight','ArrowLeft','ArrowRight','b','a'];
  let p = 0;
  function onKey(e: KeyboardEvent) {
    if (e.key === seq[p]) {
      p++;
      if (p >= seq.length) {
        p = 0;
        try { fn(); } catch (e) { console.error(e); }
      }
    } else { p = 0; }
  }
  window.addEventListener('keydown', onKey);
  return () => window.removeEventListener('keydown', onKey);
}
// src/ui/puzzle-overlay.ts
// Overlay UI for puzzle: shows subtle instructions, progress and supports hint and cancel.
export function createPuzzleOverlay(root: HTMLElement, onHint: () => void, onCancel: () => void) {
  const panel = document.createElement('div');
  panel.className = 'panel';
  panel.style.position = 'fixed';
  panel.style.top = '8%';
  panel.style.right = '6%';
  panel.style.zIndex = '60';
  panel.style.width = '320px';
  panel.innerHTML = `
    <h3>Authentification Stellaire</h3>
    <p id="p-desc">Clique les étoiles spéciales dans l'ordre du scintillement.</p>
    <div style="display:flex;gap:8px;justify-content:center;margin-top:8px">
      <button id="p-hint" class="btn">Indice</button>
      <button id="p-cancel" class="btn ghost">Annuler</button>
    </div>
    <div style="margin-top:10px">
      <div class="progress"><div id="p-fill" class="fill" style="width:0%"></div></div>
    </div>
  `;
  root.appendChild(panel);
  const hint = panel.querySelector('#p-hint') as HTMLButtonElement;
  const cancel = panel.querySelector('#p-cancel') as HTMLButtonElement;
  hint.addEventListener('click', () => onHint());
  cancel.addEventListener('click', () => onCancel());
  function setProgress(pct: number) {
    const fill = panel.querySelector('#p-fill') as HTMLElement;
    fill.style.width = `${pct}%`;
  }
  function setDesc(text: string) {
    const d = panel.querySelector('#p-desc') as HTMLElement;
    d.textContent = text;
  }
  function remove() { panel.remove(); }
  return { setProgress, setDesc, remove, element: panel };
}
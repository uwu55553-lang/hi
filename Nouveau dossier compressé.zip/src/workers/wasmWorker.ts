/**
 * Worker (TypeModule) that loads wasm simulation (if available) and runs the particle simulation.
 * Worker handles:
 * - init (width, height, maxParticles)
 * - pointer updates
 * - bursts
 * - puzzle (select secret stars, track clicks via messages)
 *
 * To keep build simple in this scaffold, wasm import is attempted but fallback to JS simulation present.
 */

let wasm: any = null;
let width = 0, height = 0;
let maxParticles = 1000;
let particles = []; // fallback JS particles
let running = false;

onmessage = async (ev) => {
  const msg = ev.data;
  if (msg.type === 'init') {
    width = msg.width; height = msg.height; maxParticles = msg.maxParticles || 1000;
    running = true;
    // try to import wasm if built (wasm/pkg)
    try {
      // dynamic import; when building, ensure path points to wasm pkg
      wasm = await import('../../wasm/pkg/wasm_sim.js').catch(() => null);
      if (wasm && wasm.run_init) {
        // initialize wasm (if available)
        wasm.run_init(width, height, maxParticles);
        postMessage({ type: 'stats', particles: 0 });
        loopWasm();
      } else {
        // fallback
        initFallback();
        loopFallback();
      }
    } catch (e) {
      console.error('WASM load failed', e);
      initFallback();
      loopFallback();
    }
  } else if (msg.type === 'pointer') {
    if (wasm && wasm.set_pointer) {
      wasm.set_pointer(msg.x, msg.y);
    } else {
      // fallback: nudge local
      // spawn small particles around pointer
      for (let i = 0; i < 2; i++) {
        particles.push({ x: msg.x + (Math.random()-0.5)*10, y: msg.y + (Math.random()-0.5)*10, vx: (Math.random()-0.5)*4, vy: (Math.random()-0.5)*4, s: Math.random()*3+1, h: (Math.random()*360), a:1 });
      }
    }
  } else if (msg.type === 'burst') {
    const count = msg.count || 50;
    for (let i = 0; i < count; i++) {
      particles.push({ x: msg.x + (Math.random()-0.5)*60, y: msg.y + (Math.random()-0.5)*60, vx: (Math.random()-0.5)*8, vy: (Math.random()-0.5)*8, s: Math.random()*4+1, h: (Math.random()*360), a:1 });
    }
    postMessage({ type: 'stats', particles: particles.length });
  } else if (msg.type === 'puzzle') {
    // spawn a subtle puzzle: create star map metadata and send to main thread as 'render' containing star positions (encoded in buffer)
    createPuzzle();
  }
};

function initFallback() {
  particles = [];
}

function loopFallback() {
  if (!running) return;
  // update particles
  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    p.vx *= 0.98;
    p.vy *= 0.98;
    p.x += p.vx;
    p.y += p.vy;
    p.s *= 0.997;
    p.a -= 0.005;
    if (p.a <= 0.02 || p.s < 0.3 || p.x < -100 || p.x > width + 100) particles.splice(i, 1);
  }

  // prepare buffer to transfer
  const farr = new Float32Array(particles.length * 5);
  for (let i = 0; i < particles.length; i++) {
    const p = particles[i];
    farr[i * 5 + 0] = p.x;
    farr[i * 5 + 1] = p.y;
    farr[i * 5 + 2] = p.s;
    farr[i * 5 + 3] = p.h;
    farr[i * 5 + 4] = p.a;
  }
  // send as transferable
  postMessage({ type: 'render', buffer: farr.buffer, meta: { t: Date.now() } }, [farr.buffer]);
  postMessage({ type: 'stats', particles: particles.length });
  setTimeout(loopFallback, 1000 / 60);
}

function loopWasm() {
  if (!running) return;
  // wasm is expected to export a function that returns a pointer/len to particles float32 buffer
  try {
    const result = wasm.step_frame(); // hypothetical API
    // result would be an ArrayBuffer
    if (result && result instanceof Uint8Array) {
      // If wasm returns bytes, send them
      postMessage({ type: 'render', buffer: result.buffer.slice(0), meta: { t: Date.now() } }, [result.buffer.slice(0)]);
    }
    postMessage({ type: 'stats', particles: wasm.particle_count ? wasm.particle_count() : 0 });
  } catch (e) {
    // fallback if API mismatch
    initFallback();
    loopFallback();
    return;
  }
  setTimeout(loopWasm, 1000 / 60);
}

function createPuzzle() {
  // create subtle star positions (few dozen) and mark some secret indices
  const count = 40;
  const farr = new Float32Array(count * 5);
  const secret = [];
  for (let i = 0; i < count; i++) {
    const x = Math.random() * width;
    const y = Math.random() * height;
    const s = 1 + Math.random() * 3;
    const h = (200 + Math.random() * 160) % 360;
    const a = 0.9;
    farr[i * 5 + 0] = x;
    farr[i * 5 + 1] = y;
    farr[i * 5 + 2] = s;
    farr[i * 5 + 3] = h;
    farr[i * 5 + 4] = a;
    if (Math.random() > 0.88) secret.push(i);
  }
  // send as a special render that main interprets as stars (meta.puzzle = true)
  postMessage({ type: 'render', buffer: farr.buffer, meta: { puzzle: true, secret } }, [farr.buffer]);
  // store secret in worker state if needed
  // For the scaffold: we simulate that clicking stars sends solved back if user clicks correct ones (not implemented here)
}
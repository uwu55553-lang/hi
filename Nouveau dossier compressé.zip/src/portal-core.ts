/* src/portal-core.ts
   Partie 1 — gros fichier TypeScript central.
   Ce fichier contient une grande partie du moteur client : gestion du canvas,
   simulation fallback, worker talk, puzzles, effets visuels, sécurité/perf.
   NOTE : c'est volontairement long et dense ; les parties suivantes (PARTIE 2/3...)
   étofferont le code (WASM, Rust, worker optimisé, backend, tests, outils).
*/

/* -------------------------------------------------------------
   UTILITAIRES GÉNÉRAUX
   Fonctions petites mais utilisées partout : clamp, rand, fps monitor, log safe
   ------------------------------------------------------------- */

function clamp(v: number, a: number, b: number) { return Math.max(a, Math.min(b, v)); }
function rand(min = 0, max = 1) { return Math.random() * (max - min) + min; }
function now() { return performance.now(); }

class Logger {
  private buf: string[] = [];
  constructor(private elId?: string) {}
  log(...args: any[]) {
    const s = args.map(a => (typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' ');
    this.buf.push(`[${new Date().toISOString()}] ${s}`);
    if (this.buf.length > 200) this.buf.shift();
    if (this.elId) {
      const el = document.getElementById(this.elId) as HTMLElement | null;
      if (el) el.textContent = this.buf.join('\n');
    } else {
      // no DOM debug
      // optionally push to console
      // console.debug(s);
    }
  }
  getAll() { return this.buf.join('\n'); }
}

/* -------------------------------------------------------------
   CAPABILITÉS MACHINE — estimation pour régler limites
   ------------------------------------------------------------- */
const deviceMemory = (navigator as any).deviceMemory || 4;
const logicalCores = (navigator as any).hardwareConcurrency || 4;
const IS_MOBILE = /Mobi|Android/i.test(navigator.userAgent);
const MAX_PARTICLES_EST = Math.max(300, Math.min(5000, Math.floor(deviceMemory * 450)));
const SAFE_PARTICLE_LIMIT = IS_MOBILE ? Math.floor(MAX_PARTICLES_EST * 0.35) : Math.floor(MAX_PARTICLES_EST * 0.85);

/* -------------------------------------------------------------
   CORE CLASSES : Particle, ParticlePool, Renderer, PortalManager
   ------------------------------------------------------------- */

/* Particle object for fallback JS sim
   Representation optimized for typed arrays if needed later.
*/
class Particle {
  x = 0; y = 0; vx = 0; vy = 0; s = 1; life = 1; h = 220; a = 1;
  constructor(x = 0, y = 0, s = 2, h = 220) {
    this.x = x; this.y = y; this.s = s; this.h = h; this.life = 1; this.a = 1;
    this.vx = rand(-3, 3); this.vy = rand(-3, 3);
  }
  update(dt: number, attractor?: { x: number; y: number }) {
    if (attractor) {
      const dx = attractor.x - this.x;
      const dy = attractor.y - this.y;
      const d2 = dx * dx + dy * dy + 0.01;
      const d = Math.sqrt(d2);
      const f = Math.min(400 / d, 8) * 0.06;
      this.vx += (dx / d) * f;
      this.vy += (dy / d) * f;
      // small swirl
      const sway = Math.sin(this.x * 0.01 + performance.now() * 0.0004) * 0.12;
      this.vx += sway;
      this.vy -= sway;
    }
    // integrate
    this.x += this.vx * dt;
    this.y += this.vy * dt;
    this.vx *= 0.96;
    this.vy *= 0.96;
    this.s *= 0.998;
    this.life -= 0.003 * dt;
    this.a = Math.max(0, this.life);
  }
}

/* ParticlePool (object pooling to avoid GC churn) */
class ParticlePool {
  private pool: Particle[] = [];
  private active: Particle[] = [];
  constructor(private limit: number) {
    for (let i = 0; i < Math.min(64, limit); i++) this.pool.push(new Particle());
  }
  spawn(x: number, y: number, count = 1, hue?: number) {
    for (let i = 0; i < count; i++) {
      if (this.active.length >= this.limit) break;
      const p = this.pool.pop() || new Particle();
      p.x = x + rand(-16, 16);
      p.y = y + rand(-16, 16);
      p.vx = rand(-6, 6);
      p.vy = rand(-6, 6);
      p.s = rand(1, 4);
      p.h = hue !== undefined ? hue + rand(-30, 30) : 220 + rand(-120, 120);
      p.life = 1;
      p.a = 1;
      this.active.push(p);
    }
  }
  update(dt: number, attractor?: { x: number; y: number }) {
    for (let i = this.active.length - 1; i >= 0; i--) {
      const p = this.active[i];
      p.update(dt, attractor);
      if (p.life <= 0 || p.s < 0.2 || isNaN(p.x)) {
        // recycle
        this.active.splice(i, 1);
        if (this.pool.length < this.limit) this.pool.push(p);
      }
    }
  }
  getActive() { return this.active; }
  countActive() { return this.active.length; }
}

/* Renderer (Canvas 2D) — optimized draw with batching and shadows */
class Renderer {
  private ctx: CanvasRenderingContext2D;
  private w = 0; private h = 0;
  private backing: HTMLCanvasElement;
  private backingCtx: CanvasRenderingContext2D;
  constructor(private canvas: HTMLCanvasElement) {
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) throw new Error('2D context non supporté');
    this.ctx = ctx;
    this.resize(canvas.width, canvas.height);
    // offscreen backing for some compositing (optional)
    this.backing = document.createElement('canvas');
    this.backingCtx = this.backing.getContext('2d')!;
  }
  resize(w: number, h: number) {
    this.canvas.width = w; this.canvas.height = h;
    this.w = w; this.h = h;
    this.backing.width = w; this.backing.height = h;
  }
  clear() {
    // subtle fade effect to create trails
    this.ctx.fillStyle = 'rgba(0,0,0,0.12)';
    this.ctx.fillRect(0, 0, this.w, this.h);
  }
  drawParticles(list: Particle[]) {
    // draw each particle with shadow and a small trail
    for (let i = 0; i < list.length; i++) {
      const p = list[i];
      this.ctx.save();
      this.ctx.beginPath();
      const alpha = clamp(p.a, 0, 1);
      this.ctx.fillStyle = `hsla(${Math.floor(p.h)},85%,58%,${alpha})`;
      // shadow less costly for many particles, cap it
      this.ctx.shadowBlur = Math.min(28, p.s * 8);
      this.ctx.shadowColor = `hsl(${Math.floor(p.h)},85%,58%)`;
      this.ctx.globalAlpha = alpha;
      this.ctx.arc(p.x, p.y, Math.max(0.25, p.s), 0, Math.PI * 2);
      this.ctx.fill();
      // trail
      this.ctx.globalAlpha = alpha * 0.35;
      this.ctx.beginPath();
      this.ctx.arc(p.x - p.vx * 2, p.y - p.vy * 2, Math.max(0.2, p.s * 0.5), 0, Math.PI * 2);
      this.ctx.fill();
      this.ctx.restore();
    }
  }
  drawVortex(x: number, y: number, radius: number, hue = 260, alpha = 0.8) {
    this.ctx.save();
    const grd = this.ctx.createRadialGradient(x, y, 0, x, y, radius);
    grd.addColorStop(0, `hsla(${hue},90%,60%,${alpha})`);
    grd.addColorStop(0.6, `hsla(${(hue+30)%360},90%,40%,${alpha*0.3})`);
    grd.addColorStop(1, 'rgba(0,0,0,0)');
    this.ctx.fillStyle = grd;
    this.ctx.beginPath();
    this.ctx.arc(x, y, radius, 0, Math.PI * 2);
    this.ctx.fill();
    this.ctx.restore();
  }
}

/* -------------------------------------------------------------
   PortalManager: orchestration, worker communication, puzzles, UI hooks
   ------------------------------------------------------------- */

type WorkerCommand =
  | { type: 'init'; width: number; height: number; maxParticles: number }
  | { type: 'pointer'; x: number; y: number }
  | { type: 'burst'; x: number; y: number; count?: number; hue?: number }
  | { type: 'puzzle' }
  | { type: 'pulse'; x: number; y: number }
  | { type: 'shutdown' };

class PortalManager {
  private canvas: HTMLCanvasElement;
  private renderer: Renderer;
  private pool: ParticlePool;
  private worker?: Worker;
  private logger = new Logger('debug-log');
  private lastTime = now();
  private running = false;
  private pointer = { x: 0, y: 0 };
  private attractorEnabled = false;
  private puzzleActive = false;
  private puzzleSecret: number[] = [];
  private puzzleProgress = 0;
  private allowedToSpawn = true;
  private particleLimit = SAFE_PARTICLE_LIMIT;
  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.renderer = new Renderer(canvas);
    this.pool = new ParticlePool(this.particleLimit);
    this.installListeners();
    this.trySpawnWorker();
  }
  private installListeners() {
    window.addEventListener('resize', () => this.onResize());
    window.addEventListener('mousemove', (e) => {
      this.pointer.x = e.clientX; this.pointer.y = e.clientY;
      if (this.worker) this.worker.postMessage({ type: 'pointer', x: e.clientX, y: e.clientY });
    });
    window.addEventListener('click', (e) => {
      this.spawnBurst(e.clientX, e.clientY, 40, undefined);
      if (this.puzzleActive) this.handlePuzzleClick(e.clientX, e.clientY);
    });

    // UI buttons
    const btnOpen = document.getElementById('btn-open') as HTMLButtonElement | null;
    const btnPuzzle = document.getElementById('btn-puzzle') as HTMLButtonElement | null;
    const btnOptions = document.getElementById('btn-options') as HTMLButtonElement | null;
    if (btnOpen) btnOpen.addEventListener('click', () => this.doOpenSequence());
    if (btnPuzzle) btnPuzzle.addEventListener('click', () => this.openPuzzlePanel());
    if (btnOptions) btnOptions.addEventListener('click', () => this.toggleOptions());
  }
  private onResize() {
    this.renderer.resize(window.innerWidth, window.innerHeight);
  }
  private trySpawnWorker() {
    // create worker if available and not mobile
    if (typeof Worker !== 'undefined' && !IS_MOBILE) {
      try {
        // Worker bundled as module in same dir — will be provided in PARTIE 2
        this.worker = new Worker('./src/portal-worker.js', { type: 'module' });
        this.worker.onmessage = (ev: MessageEvent) => this.handleWorkerMessage(ev.data);
        this.worker.onerror = (ev) => this.logger.log('Worker error', ev);
        this.worker.postMessage({ type: 'init', width: window.innerWidth, height: window.innerHeight, maxParticles: this.particleLimit });
        this.logger.log('Worker spawned');
        return;
      } catch (err) {
        this.logger.log('Worker spawn failed, falling back to JS simulation', err);
      }
    } else {
      this.logger.log('Worker unavailable or mobile — using fallback simulation');
    }
  }
  private handleWorkerMessage(msg: any) {
    // handle worker's render buffer or stats
    if (msg.type === 'render-buffer') {
      // buffer of Float32 with [x,y,s,h,a,...]
      try {
        const buf = new Float32Array(msg.buffer);
        // draw directly using renderer (fast path)
        this.renderer.clear();
        // draw vortex if provided
        if (msg.vortex) this.renderer.drawVortex(msg.vortex.x, msg.vortex.y, msg.vortex.r, msg.vortex.h);
        // map buffer to pseudo-particles for drawing
        const tmp: Particle[] = [];
        for (let i = 0; i < buf.length; i += 5) {
          const p = new Particle();
          p.x = buf[i]; p.y = buf[i + 1]; p.s = buf[i + 2]; p.h = buf[i + 3]; p.a = buf[i + 4];
          tmp.push(p);
        }
        this.renderer.drawParticles(tmp);
        // free buffer ownership — worker server will manage
      } catch (e) {
        this.logger.log('render-buffer failed', e);
      }
    } else if (msg.type === 'stats') {
      (document.getElementById('particleCount') as HTMLElement).textContent = `✨ Particules: ${msg.count}`;
      (document.getElementById('perfHint') as HTMLElement).textContent = `Perf: ${msg.fps || '--'}fps`;
    } else if (msg.type === 'puzzle-data') {
      // worker sent positions for a puzzle: show stars overlay, build secret order
      this.preparePuzzleFromData(msg.positions, msg.secret);
    } else if (msg.type === 'puzzle-solved') {
      this.onPuzzleSolved();
    } else {
      this.logger.log('worker-msg', msg);
    }
  }
  private spawnBurst(x: number, y: number, count = 24, hue?: number) {
    // prefer worker if exists
    if (this.worker) {
      this.worker.postMessage({ type: 'burst', x, y, count, hue });
      return;
    }
    // fallback: spawn in pool
    this.pool.spawn(x, y, count, hue);
  }
  private onResizeCanvas() { this.renderer.resize(window.innerWidth, window.innerHeight); }
  start() {
    if (this.running) return;
    this.renderer.resize(window.innerWidth, window.innerHeight);
    this.running = true;
    this.lastTime = now();
    requestAnimationFrame(() => this.loop());
  }
  private loop() {
    if (!this.running) return;
    const t = now();
    const dt = clamp((t - this.lastTime) * 0.06, 0.5, 4); // scaled dt
    this.lastTime = t;
    // if no worker, update pool and draw
    if (!this.worker) {
      // optionally spawn ambient particles when attractor enabled
      if (this.attractorEnabled && this.pool.countActive() < this.particleLimit) {
        this.pool.spawn(this.pointer.x, this.pointer.y, 3, 260 + rand(-40, 40));
      }
      this.pool.update(dt, this.attractorEnabled ? this.pointer : undefined);
      this.renderer.clear();
      this.renderer.drawParticles(this.pool.getActive());
    }
    // request next frame
    requestAnimationFrame(() => this.loop());
  }

  /* ------------------------
     Puzzle handling (fallback off-worker)
     ------------------------ */
  openPuzzlePanel() {
    // request worker to create puzzle data; fallback will create local
    if (this.worker) {
      this.worker.postMessage({ type: 'puzzle' });
    } else {
      this.createLocalPuzzle();
    }
    // toggle UI
    const panel = document.getElementById('puzzlePanel')!;
    panel.classList.remove('hidden'); panel.setAttribute('aria-hidden', 'false');
    this.puzzleActive = true;
  }
  closePuzzlePanel() {
    const panel = document.getElementById('puzzlePanel')!;
    panel.classList.add('hidden'); panel.setAttribute('aria-hidden', 'true');
    this.puzzleActive = false; this.puzzleProgress = 0;
    const bar = document.getElementById('puzzle-bar') as HTMLElement;
    if (bar) bar.style.width = '0%';
  }
  createLocalPuzzle() {
    // generate star positions and secret indices
    const positions: { x: number; y: number; s: number; h: number }[] = [];
    const secret: number[] = [];
    const count = 48;
    for (let i = 0; i < count; i++) {
      positions.push({ x: rand(40, window.innerWidth - 40), y: rand(40, window.innerHeight - 40), s: rand(1, 3.2), h: 180 + rand(-60, 60) });
      if (Math.random() > 0.88) secret.push(i);
    }
    this.preparePuzzleFromData(positions, secret);
  }
  preparePuzzleFromData(positions: any[], secret: number[]) {
    // draw small DOM stars on top of canvas for interactivity
    const root = document.getElementById('ui-layer')!;
    // remove old stars
    const old = document.querySelectorAll('.puzzle-star');
    old.forEach(o => o.remove());
    const stars: HTMLElement[] = [];
    for (let i = 0; i < positions.length; i++) {
      const p = positions[i];
      const el = document.createElement('div');
      el.className = 'puzzle-star';
      el.style.position = 'absolute';
      el.style.left = `${p.x - p.s}px`;
      el.style.top = `${p.y - p.s}px`;
      el.style.width = `${p.s * 2}px`;
      el.style.height = `${p.s * 2}px`;
      el.style.borderRadius = '50%';
      el.style.zIndex = '20';
      el.style.pointerEvents = 'auto';
      el.style.background = `hsl(${p.h}, 100%, 85%)`;
      el.dataset.idx = String(i);
      // subtle twinkle animation offset by index
      el.style.opacity = '0.95';
      el.style.transition = 'transform 0.28s ease, box-shadow 0.32s ease';
      root.appendChild(el);
      stars.push(el);
    }
    // set secret
    this.puzzleSecret = secret.slice().sort((a,b) => a-b); // deterministic ordering — could be randomized
    this.puzzleProgress = 0;
    // add click handlers
    stars.forEach(st => st.addEventListener('click', (e) => {
      const idx = Number((e.currentTarget as HTMLElement).dataset.idx);
      this.onPuzzleStarClicked(idx);
    }));
    // small hint
    const desc = document.getElementById('puzzle-desc')!;
    desc.textContent = `Il y a ${this.puzzleSecret.length} étoiles-clés ; clique-les dans l'ordre.`;
  }
  private onPuzzleStarClicked(idx: number) {
    if (!this.puzzleActive) return;
    const expected = this.puzzleSecret[this.puzzleProgress];
    if (idx === expected) {
      // correct
      this.puzzleProgress++;
      const pct = Math.round((this.puzzleProgress / Math.max(1, this.puzzleSecret.length)) * 100);
      const bar = document.getElementById('puzzle-bar') as HTMLElement;
      bar.style.width = `${pct}%`;
      // visual feedback
      const el = document.querySelector(`.puzzle-star[data-idx="${idx}"]`) as HTMLElement | null;
      if (el) {
        el.style.transform = 'scale(1.45)';
        el.style.boxShadow = `0 0 30px rgba(255,255,255,0.8)`;
        setTimeout(()=>{ el.style.transform=''; el.style.boxShadow=''; }, 900);
      }
      // small particle burst around star
      const rootRect = document.getElementById('ui-layer')!.getBoundingClientRect();
      const starEl = document.querySelector(`.puzzle-star[data-idx="${idx}"]`) as HTMLElement;
      if (starEl) {
        const rect = starEl.getBoundingClientRect();
        this.spawnBurst(rect.left + rect.width / 2, rect.top + rect.height / 2, 18, 280);
      }
      if (this.puzzleProgress >= this.puzzleSecret.length) {
        this.onPuzzleSolved();
      }
    } else {
      // wrong click: increment fail, show glitch, small penalty
      this.indicateWrongClick();
    }
  }
  private handlePuzzleClick(x: number, y: number) {
    // optional: click in empty space creates ring
    this.spawnBurst(x, y, 6, 200 + rand(-40, 40));
  }
  private indicateWrongClick() {
    // quick glitch effect on main panel; non-destructive and reversible
    const root = document.getElementById('mainPanel')!;
    root.classList.add('glitch');
    setTimeout(() => root.classList.remove('glitch'), 850);
    this.spawnBurst(rand(40, window.innerWidth - 40), rand(40, window.innerHeight - 40), 12, 280);
  }
  private onPuzzleSolved() {
    // celebrate: confetti, pulses, open portal video after a short delay
    this.closePuzzlePanel();
    // celebrate visually using particle bursts
    const cx = window.innerWidth / 2, cy = window.innerHeight / 2;
    for (let i = 0; i < 6; i++) {
      setTimeout(() => this.spawnBurst(cx + rand(-200,200), cy + rand(-120,120), 140, 260 + i*20), i * 140);
    }
    // open video overlay after a short delay
    setTimeout(() => this.openPortalVideo(), 1600);
  }

  /* ------------------------
     Open Sequence & Video
     ------------------------ */
  private doOpenSequence() {
    // central sequence: spawn several bursts and rings
    const cx = window.innerWidth / 2, cy = window.innerHeight / 2;
    for (let i = 0; i < 10; i++) {
      setTimeout(() => this.spawnBurst(cx + rand(-360, 360), cy + rand(-240, 240), 60, 220 + rand(-80,80)), i * 90);
    }
    // after sequence, reveal the fullscreen video
    setTimeout(() => this.openPortalVideo(), 1800);
  }
  private openPortalVideo() {
    const overlay = document.getElementById('video-overlay')!;
    overlay.classList.remove('hidden');
    overlay.setAttribute('aria-hidden', 'false');
    const video = document.getElementById('portal-video') as HTMLVideoElement;
    try { video.play().catch(()=>{}); } catch (e) {}
    // attempt fullscreen politely
    const el = document.documentElement;
    if (el.requestFullscreen) el.requestFullscreen().catch(()=>{});
    // wire close
    const close = document.getElementById('video-close')!;
    close.addEventListener('click', () => {
      try { video.pause(); video.currentTime = 0; } catch (e) {}
      overlay.classList.add('hidden'); overlay.setAttribute('aria-hidden', 'true');
      if (document.fullscreenElement) document.exitFullscreen().catch(()=>{});
    }, { once: true });
  }

  /* ------------------------
     Options toggles
     ------------------------ */
  private toggleOptions() {
    // simple options panel for perf toggles (placeholder)
    const keep = confirm('Désactiver certains effets lourds pour économie de CPU ? OK = oui');
    if (keep) {
      // reduce allowed particle limit
      this.particleLimit = Math.floor(this.particleLimit * 0.45);
      this.pool = new ParticlePool(this.particleLimit);
      alert('Mode éco activé — effets réduits');
    }
  }

  /* shutdown */
  shutdown() {
    this.running = false;
    if (this.worker) {
      this.worker.postMessage({ type: 'shutdown' });
      try { this.worker.terminate(); } catch (e) {}
      this.worker = undefined;
    }
  }
}

/* -------------------------------------------------------------
   INITIALIZATION
   Create PortalManager and start animation loop.
   ------------------------------------------------------------- */

(function mainBootstrap() {
  const canvas = document.getElementById('portal-canvas') as HTMLCanvasElement;
  if (!canvas) {
    console.error('Canvas introuvable');
    return;
  }
  const portal = new PortalManager(canvas);
  portal.start();
  // expose for debugging in dev console
  (window as any).__PORTAL__ = portal;

  // small performance meter update loop
  setInterval(() => {
    const perf = (window as any).performance;
    // update perf hint if any
    const el = document.getElementById('perfHint');
    if (el) el.textContent = `Perf: ${(Math.round( (performance as any).now() % 1000 ) )}ms`;
  }, 1000);
})();

/* End of PARTIE 1 — src/portal-core.ts
   J'ai posé la base : moteur fallback, UI hooks, puzzle simple, video overlay, worker handshake.
   La PARTIE 2 contiendra :
   - worker module (ESM) code (src/portal-worker.ts) qui gérera la simulation en Thread,
   - implémentation WASM scaffold (Rust) plus glue (wasm/pkg),
   - serveurs et utilitaires (Go, Node) et multiples autres fichiers pour atteindre ~10k lignes.
*/
import { createPortalUI } from './app/ui';
import { Portal } from './app/Portal';

// bootstrap canvas and app
const canvas = document.getElementById('portalCanvas') as HTMLCanvasElement;
canvas.width = innerWidth;
canvas.height = innerHeight;

const portal = new Portal(canvas);
createPortalUI(document.getElementById('ui-root')!, portal);

window.addEventListener('resize', () => {
  canvas.width = innerWidth;
  canvas.height = innerHeight;
  portal.resize();
});

// start
portal.start();
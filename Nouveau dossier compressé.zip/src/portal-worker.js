// Transpiled / fallback worker (ES module) for environments that cannot import TS worker directly.
// This file mirrors src/portal-worker.ts logic but as plain JS for simpler bundlers.
// Place at src/portal-worker.js so PortalManager can spawn Worker('./src/portal-worker.js', {type:'module'})
/* eslint-disable no-var */
var width = 800, height = 600, maxParticles = 1000;
var useWasm = false;
var wasm = null;
var lastFrame = performance.now();
var fpsMeasure = { last: performance.now(), ticks: 0, lastFps: 60 };
var particles = [];
var pointer = { x: 0, y: 0, enabled: false };

function rand(min, max) {
  if (min === void 0) { min = 0; }
  if (max === void 0) { max = 1; }
  return Math.random() * (max - min) + min;
}
function now() { return performance.now(); }

async function tryLoadWasm() {
  // Try to import the wasm pack if present
  try {
    // path relative to worker file (adjust if build places wasm elsewhere)
    wasm = await import('../../wasm/pkg/wasm_sim.js');
    if (wasm && typeof wasm.run_init === 'function') {
      useWasm = true;
      postMessage({ type: 'status', text: 'WASM loaded' });
      return true;
    }
  } catch (e) {
    useWasm = false;
  }
  return false;
}

function spawnFallback(x, y, count, hue) {
  if (count === void 0) { count = 10; }
  if (hue === void 0) { hue = 220; }
  for (var i = 0; i < count; i++) {
    var p = {
      x: x + rand(-24, 24),
      y: y + rand(-24, 24),
      vx: rand(-6, 6),
      vy: rand(-6, 6),
      s: rand(1, 4),
      h: hue + rand(-30, 30),
      a: 1,
      life: 1
    };
    if (particles.length < maxParticles) particles.push(p);
  }
}

function stepFallback(dt) {
  for (var i = particles.length - 1; i >= 0; i--) {
    var p = particles[i];
    if (pointer.enabled) {
      var dx = pointer.x - p.x;
      var dy = pointer.y - p.y;
      var d2 = dx * dx + dy * dy + 0.1;
      var d = Math.sqrt(d2);
      var force = Math.min(800 / d, 20) * 0.04;
      p.vx += (dx / d) * force;
      p.vy += (dy / d) * force;
      p.vx += Math.sin((p.y + now() * 0.001) * 0.01) * 0.05;
    }
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.vx *= 0.96;
    p.vy *= 0.96;
    p.s *= 0.998;
    p.life -= 0.003 * dt;
    p.a = Math.max(0, p.life);
    if (p.life <= 0 || p.s <= 0.2 || p.x < -100 || p.x > width + 100 || p.y < -100 || p.y > height + 100) {
      particles.splice(i, 1);
    }
  }
}

function buildRenderBufferFromFallback() {
  var farr = new Float32Array(particles.length * 5);
  for (var i = 0; i < particles.length; i++) {
    var p = particles[i];
    farr[i * 5 + 0] = p.x;
    farr[i * 5 + 1] = p.y;
    farr[i * 5 + 2] = p.s;
    farr[i * 5 + 3] = p.h;
    farr[i * 5 + 4] = p.a;
  }
  return farr.buffer;
}

// Puzzle
var puzzleStars = [];
var puzzleSecret = [];
var puzzleActive = false;
var puzzleClicks = 0;

function createPuzzleData(count) {
  if (count === void 0) { count = 40; }
  puzzleStars = [];
  puzzleSecret = [];
  for (var i = 0; i < count; i++) {
    puzzleStars.push({
      x: rand(40, width - 40),
      y: rand(40, height - 40),
      s: rand(1, 3),
      h: 200 + rand(-80, 80)
    });
    if (Math.random() > 0.88) puzzleSecret.push(i);
  }
  if (puzzleSecret.length < 3) {
    while (puzzleSecret.length < 3) {
      var v = Math.floor(rand(0, count));
      if (!puzzleSecret.includes(v)) puzzleSecret.push(v);
    }
  }
  puzzleActive = true;
  puzzleClicks = 0;
  var farr = new Float32Array(count * 5);
  for (var i = 0; i < count; i++) {
    var s = puzzleStars[i];
    farr[i * 5 + 0] = s.x;
    farr[i * 5 + 1] = s.y;
    farr[i * 5 + 2] = s.s;
    farr[i * 5 + 3] = s.h;
    farr[i * 5 + 4] = 0.92;
  }
  var secretCopy = puzzleSecret.slice();
  postMessage({ type: 'render', buffer: farr.buffer, meta: { puzzle: true, secret: secretCopy } }, [farr.buffer]);
}

function handleStarClick(index) {
  if (!puzzleActive) return;
  var expected = puzzleSecret[puzzleClicks];
  if (index === expected) {
    puzzleClicks++;
    var s = puzzleStars[index];
    spawnFallback(s.x, s.y, 14, 260);
    if (puzzleClicks >= puzzleSecret.length) {
      puzzleActive = false;
      postMessage({ type: 'puzzle-solved' });
    }
  } else {
    spawnFallback(rand(40, width - 40), rand(40, height - 40), 12, 340);
  }
}

var running = false;
var loopHandle = null;

function startLoop() {
  if (running) return;
  running = true;
  lastFrame = performance.now();
  fpsMeasure = { last: performance.now(), ticks: 0, lastFps: 60 };
  tryLoadWasm().then(function () {
    if (useWasm && wasm && typeof wasm.run_init === 'function') {
      try {
        wasm.run_init(width, height, maxParticles);
      } catch (e) { }
    }
    function loop() {
      if (!running) return;
      var t = performance.now();
      var dtMs = t - lastFrame;
      lastFrame = t;
      var dt = clampDt(dtMs);
      fpsMeasure.ticks++;
      if (t - fpsMeasure.last > 1000) {
        fpsMeasure.lastFps = Math.round((fpsMeasure.ticks * 1000) / (t - fpsMeasure.last));
        fpsMeasure.ticks = 0;
        fpsMeasure.last = t;
      }
      if (useWasm && wasm) {
        try {
          var arr = wasm.step_frame();
          if (arr && arr.buffer) {
            var buffer = arr.buffer.slice(0);
            postMessage({ type: 'render', buffer: buffer, meta: { t: Date.now() } }, [buffer]);
          } else {
            postMessage({ type: 'stats', particles: wasm.particle_count ? wasm.particle_count() : 0, fps: fpsMeasure.lastFps });
          }
        } catch (e) {
          stepFallback(dt);
          var sb = buildRenderBufferFromFallback();
          postMessage({ type: 'render', buffer: sb, meta: { t: Date.now() } }, [sb]);
          postMessage({ type: 'stats', particles: particles.length, fps: fpsMeasure.lastFps });
        }
      } else {
        stepFallback(dt);
        var sendBuf = buildRenderBufferFromFallback();
        postMessage({ type: 'render', buffer: sendBuf, meta: { t: Date.now() } }, [sendBuf]);
        postMessage({ type: 'stats', particles: particles.length, fps: fpsMeasure.lastFps });
      }
      loopHandle = setTimeout(loop, 1000 / 60);
    }
    loop();
  });
}
function clampDt(ms) { return Math.max(0.5, Math.min(3.0, ms / (1000 / 60))); }

onmessage = function (ev) {
  var msg = ev.data;
  if (!msg || typeof msg.type !== 'string') return;
  switch (msg.type) {
    case 'init':
      width = msg.width; height = msg.height; maxParticles = msg.maxParticles || 1000;
      tryLoadWasm().then(function () {
        if (useWasm && wasm && typeof wasm.run_init === 'function') {
          try { wasm.run_init(width, height, maxParticles); } catch (e) { }
        }
        postMessage({ type: 'stats', particles: useWasm ? (wasm.particle_count ? wasm.particle_count() : 0) : particles.length, fps: 60 });
        startLoop();
      });
      break;
    case 'pointer':
      pointer.x = msg.x; pointer.y = msg.y; pointer.enabled = true;
      if (useWasm && wasm && typeof wasm.set_pointer === 'function') {
        try { wasm.set_pointer(msg.x, msg.y); } catch (e) { }
      }
      break;
    case 'burst':
      if (useWasm && wasm && typeof wasm.burst === 'function') {
        try { wasm.burst(msg.x, msg.y, msg.count || 60, msg.hue || 220); } catch (e) { }
      } else {
        spawnFallback(msg.x, msg.y, msg.count || 60, msg.hue || 220);
      }
      break;
    case 'puzzle':
      createPuzzleData(48);
      break;
    case 'star_click':
      handleStarClick(msg.index);
      break;
    case 'pulse':
      for (var i = 0; i < 5; i++) {
        if (useWasm && wasm && typeof wasm.burst === 'function') {
          try { wasm.burst(msg.x + rand(-80, 80), msg.y + rand(-80, 80), 40, 220 + i * 10); } catch (e) { }
        } else {
          spawnFallback(msg.x + rand(-80, 80), msg.y + rand(-80, 80), 40, 220 + i * 10);
        }
      }
      break;
    case 'shutdown':
      running = false;
      if (loopHandle) clearTimeout(loopHandle);
      postMessage({ type: 'status', text: 'worker shutdown' });
      break;
    default:
      break;
  }
};